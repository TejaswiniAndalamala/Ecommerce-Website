import React, { Fragment } from "react";
import { Route, Link } from "react-router-dom";

import { useDispatch, useSelector } from "react-redux";
import { useAlert } from "react-alert";
import { logout } from "../../actions/userActions";
import LogoIMG from "../../assets/Logo1.png";

import Search from "./Search";

import "../../App.css";
import { DropdownButton, Dropdown } from "react-bootstrap";
import { DownArrowBtn } from "../../assets/icons/icons";

const Header = () => {
  const alert = useAlert();
  const dispatch = useDispatch();

  const { user, loading } = useSelector((state) => state.auth);
  const { cartItems } = useSelector((state) => state.cart);

  const logoutHandler = () => {
    dispatch(logout());
    alert.success("Logged out successfully.");
  };

  function handleButtonClick(route) {
    console.log(route);
  }

  const products = [
    {
      id: 1,
      name: "Electronics",
      route: "Electronics",
    },
    {
      id: 2,
      name: "Cameras",
      route: "Cameras",
    },
    {
      id: 3,
      name: "Laptops",
      route: "Laptops",
    },
    {
      id: 4,
      name: "Accessories",
      route: "Accessories",
    },
    {
      id: 5,
      name: "Headphones",
      route: "Headphones",
    },
    {
      id: 1,
      name: "Electronics",
      route: "Electronics",
    },
    {
      id: 6,
      name: "Food",
      route: "Food",
    },
    {
      id: 7,
      name: "Books",
      route: "Books",
    },
    {
      id: 8,
      name: "Clothes/Shoes",
      route: "Clothes/Shoes",
    },
    {
      id: 9,
      name: "Beauty/Health",
      route: "Beauty/Health",
    },
    {
      id: 10,
      name: "Sports",
      route: "Sports",
    },
    {
      id: 11,
      name: "Outdoor",
      route: "Outdoor",
    },
    {
      id: 12,
      name: "Home",
      route: "Home",
    },
  ];

  return (
    <Fragment>
      <nav className="navbar row">
        <div className="col-12 col-md-2">
          <div className="navbar-brand">
            <Link to="/">
              <svg
                className="ml-5"
                fill="#fff"
                width={40}
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 448 512"
              >
                <path d="M388.3 104.1a4.7 4.7 0 0 0 -4.4-4c-2 0-37.2-.8-37.2-.8s-21.6-20.8-29.6-28.8V503.2L442.8 472S388.7 106.5 388.3 104.1zM288.7 70.5a116.7 116.7 0 0 0 -7.2-17.6C271 32.9 255.4 22 237 22a15 15 0 0 0 -4 .4c-.4-.8-1.2-1.2-1.6-2C223.4 11.6 213 7.6 200.6 8c-24 .8-48 18-67.3 48.8-13.6 21.6-24 48.8-26.8 70.1-27.6 8.4-46.8 14.4-47.2 14.8-14 4.4-14.4 4.8-16 18-1.2 10-38 291.8-38 291.8L307.9 504V65.7a41.7 41.7 0 0 0 -4.4 .4S297.9 67.7 288.7 70.5zM233.4 87.7c-16 4.8-33.6 10.4-50.8 15.6 4.8-18.8 14.4-37.6 25.6-50 4.4-4.4 10.4-9.6 17.2-12.8C232.2 54.9 233.8 74.5 233.4 87.7zM200.6 24.4A27.5 27.5 0 0 1 215 28c-6.4 3.2-12.8 8.4-18.8 14.4-15.2 16.4-26.8 42-31.6 66.5-14.4 4.4-28.8 8.8-42 12.8C131.3 83.3 163.8 25.2 200.6 24.4zM154.2 244.6c1.6 25.6 69.3 31.2 73.3 91.7 2.8 47.6-25.2 80.1-65.7 82.5-48.8 3.2-75.7-25.6-75.7-25.6l10.4-44s26.8 20.4 48.4 18.8c14-.8 19.2-12.4 18.8-20.4-2-33.6-57.2-31.6-60.8-86.9-3.2-46.4 27.2-93.3 94.5-97.7 26-1.6 39.2 4.8 39.2 4.8L221.4 225.4s-17.2-8-37.6-6.4C154.2 221 153.8 239.8 154.2 244.6zM249.4 82.9c0-12-1.6-29.2-7.2-43.6 18.4 3.6 27.2 24 31.2 36.4Q262.6 78.7 249.4 82.9z" />
              </svg>
            </Link>
          </div>
        </div>
        <div className="col-md-1">
          <DropdownButton title={<DownArrowBtn />}>
            {products.map((product) => {
              return (
                <Dropdown.Item key={product.id}>
                  <Link
                    className="dropdown-link"
                    to={`/products?category=${product.route}`}
                  >
                    {product.name}
                  </Link>
                </Dropdown.Item>
              );
            })}
          </DropdownButton>
        </div>
        <div className="col-12 col-md-6 mt-2 mt-md-0">
          <Route render={({ history }) => <Search history={history} />} />
        </div>

        <div className="col-12 col-md-2 mt-4 mt-md-0 text-center">
          <Link
            to="/cart"
            style={{ textDecoration: "none", position: "relative" }}
          >
            <span id="cart" className="mt-2 mr-4">
              <svg
                width={30}
                fill="#fff"
                style={{ position: "absolute", top: "0rem" }}
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 576 512"
              >
                <path d="M0 24C0 10.7 10.7 0 24 0H69.5c22 0 41.5 12.8 50.6 32h411c26.3 0 45.5 25 38.6 50.4l-41 152.3c-8.5 31.4-37 53.3-69.5 53.3H170.7l5.4 28.5c2.2 11.3 12.1 19.5 23.6 19.5H488c13.3 0 24 10.7 24 24s-10.7 24-24 24H199.7c-34.6 0-64.3-24.6-70.7-58.5L77.4 54.5c-.7-3.8-4-6.5-7.9-6.5H24C10.7 48 0 37.3 0 24zM128 464a48 48 0 1 1 96 0 48 48 0 1 1 -96 0zm336-48a48 48 0 1 1 0 96 48 48 0 1 1 0-96z" />
              </svg>
            </span>

            <span
              className=" rounded-circle"
              style={{ position: "absolute", fontSize: "0.7rem" }}
              id="cart_count"
            >
              {cartItems.length}
            </span>
          </Link>

          {user ? (
            <div className="ml-4 dropdown d-inline">
              <Link
                to="#!"
                className="btn dropdown-toggle text-white mr-4"
                type="button"
                id="dropDownMenuButton"
                data-toggle="dropdown"
                aria-haspopup="true"
                aria-expanded="false"
              >
                <figure className="avatar avatar-nav">
                  <img
                    src={user.avatar && user.avatar.url}
                    alt={user && user.name}
                    className="rounded-circle"
                  />
                </figure>
                <span>{user && user.name}</span>
              </Link>

              <div
                className="dropdown-menu"
                aria-labelledby="dropDownMenuButton"
              >
                {user && user.role === "admin" && (
                  <Link className="dropdown-item" to="/dashboard">
                    Dashboard
                  </Link>
                )}
                <Link className="dropdown-item" to="/orders/me">
                  Orders
                </Link>
                <Link className="dropdown-item" to="/me">
                  Profile
                </Link>
                <Link
                  className="dropdown-item text-danger"
                  to="/"
                  onClick={logoutHandler}
                >
                  Logout
                </Link>
              </div>
            </div>
          ) : (
            !loading && (
              <Link to="/login" className="btn ml-4" id="login_btn">
                Login
              </Link>
            )
          )}
        </div>
      </nav>
    </Fragment>
  );
};

export default Header;
